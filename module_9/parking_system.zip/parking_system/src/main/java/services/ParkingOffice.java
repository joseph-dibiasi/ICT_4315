package services;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.UUID;

import managers.PermitManager;
import managers.TransactionManager;
import models.Address;
import models.Car;
import models.Customer;
import models.ParkingCharge;
import models.ParkingLot;
import observers.ParkingObserver;

/*
 * ParkingOffice is the central class that manages customers, parking lots, and parking transactions.
 * It provides methods for registering customers and cars, processing parking events, and calculating fees.
 * It uses PermitManager to handle customer and car registrations, and TransactionManager to handle parking transactions and fee calculations.
 * ParkingOffice also implements the Observer pattern to receive updates from ParkingLot when cars are parked or leave.
 * To handle multi-threaded access, methods that modify shared state (like customers and lots) are synchronized to ensure thread safety.
 */
public class ParkingOffice {

	private String name;
	private Address address;
	private List<Customer> customers;
	private List<ParkingLot> lots;

	// managers
	private PermitManager permitManager;
	private TransactionManager transactionManager;

	public ParkingOffice() {
		this(new PermitManager(), new TransactionManager());
		this.customers = new ArrayList<>();
		this.lots = new ArrayList<>();

	}

	public ParkingOffice(PermitManager permitManager, TransactionManager transactionManager) {
		this.customers = new ArrayList<>();
		this.lots = new ArrayList<>();
		this.permitManager = permitManager != null ? permitManager : new PermitManager();
		this.transactionManager = transactionManager != null ? transactionManager : new TransactionManager();
	}

	public ParkingOffice(String name, Address address) {
		this.name = name;
		this.address = address;
		this.customers = new ArrayList<>();
		this.lots = new ArrayList<>();
		this.permitManager = new PermitManager();
		this.transactionManager = new TransactionManager();
	}
	
	public String value(Properties properties, String key) {
		return properties.getProperty(key, "").trim();
	}

	public synchronized Customer register(Customer customer) {
		Customer registeredCustomer = permitManager.register(customer.getName(), customer.getAddress(), customer.getPhoneNumber());
		if (registeredCustomer.getCars() == null) {
			registeredCustomer.setCars(new ArrayList<Car>());
		}
		this.customers.add(registeredCustomer);
		return registeredCustomer;
	}

	public synchronized Car register(Car car) {
		Customer customer = getCustomer(car.getOwner());
		if (customer == null) {
			throw new IllegalArgumentException("Unknown car owner: " + car.getOwner());
		}
		Car registeredCar = permitManager.registerCar(customer.getCustomerId(), customer.getName(), car.getLicense(),
				car.getType());
		customer.getCars().add(registeredCar);
		return registeredCar;
	}

    

	public ParkingCharge park(ParkingLot lot, Car car) {
		// Use the lot's observable park method (notifies observers)
		return lot.park(car);
	}

	public ParkingCharge leave(Instant exitTime, ParkingLot lot, Car car) {
		try {
			return transactionManager.leave(exitTime, lot, car);
		} catch (Exception e) {
			lot.getParkedCars().remove(car);
			throw new RuntimeException("Failed to Process Parking Exit: " + e.getMessage());
		}
	}

	public void updateDailyFees() {
		synchronized (this) {
			transactionManager.updateDailyFees(lots);
		}
	}

	public void calculateCustomerMonthlyBill() {
		synchronized (this) {
			for (Customer customer : this.customers) {
				transactionManager.calculateCustomerMonthlyBill(customer);
			}
		}
	}

	/**
	 * Return collection of all customer ids.
	 */
	public List<UUID> getCustomerIds() {
		return this.customers.stream().map(Customer::getCustomerId).toList();
	}

	/**
	 * Return distinct collection of all permit ids (derived from cars' owner ids).
	 */
	public List<UUID> getPermitIds() {
		List<Car> allCustomerCars = this.customers.stream().flatMap(c -> c.getCars().stream()).toList();

		return allCustomerCars.stream().map(Car::getOwner).distinct().toList();
	}

	/**
	 * Return distinct collection of permit ids for the specified customer.
	 */
	public List<UUID> getPermitIds(Customer customer) {
		if (customer == null) {
			return List.of();
		}
		return customer.getCars().stream().map(Car::getOwner).distinct().toList();
	}

	/*
	 * For a method to return only a single customer, name is not reliable. A large
	 * university could have several people with the same name; using the unique
	 * customerId is more reliable.
	 */
	public Customer getCustomer(UUID customerId) {
		return this.getCustomers().stream().filter(c -> c.getCustomerId().equals(customerId)).findFirst().orElse(null);

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public synchronized void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	public List<ParkingLot> getLots() {
		return lots;
	}

	public synchronized void setLots(List<ParkingLot> lots) {
		this.lots = lots != null ? lots : new ArrayList<>();
		if (this.transactionManager != null) {
			for (ParkingLot lot : this.lots) {
				lot.addObserver(ParkingObserver.createAndRegister(this, this.transactionManager));
			}
		}
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, customers, lots, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParkingOffice other = (ParkingOffice) obj;
		return Objects.equals(address, other.address) && Objects.equals(customers, other.customers)
				&& Objects.equals(lots, other.lots) && Objects.equals(name, other.name);
	}

}
